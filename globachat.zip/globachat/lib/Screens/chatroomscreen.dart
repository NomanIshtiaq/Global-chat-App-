import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:globachat/providers/UserProvider.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class Chatroomscreen extends StatefulWidget {
  String chatroomName;
  String chatroomid;
  Chatroomscreen({
    super.key,
    required this.chatroomName,
    required this.chatroomid,
  });

  @override
  State<Chatroomscreen> createState() => _ChatroomscreenState();
}

class _ChatroomscreenState extends State<Chatroomscreen> {
  var db = FirebaseFirestore.instance;

  TextEditingController messageText = TextEditingController();
  void sendmessages() async {
    if (messageText.text.isEmpty) {
      return;
    }
    Map<String, dynamic> messagetosend = {
      "text": messageText.text,
      "sender_name": Provider.of<UserProvider>(context, listen: false).username,
      "chatroomid": widget.chatroomid,

      "timestamp": FieldValue.serverTimestamp(),
    };
    await db.collection("message").add(messagetosend);
    messageText.text = "";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.chatroomName)),
      body: Column(
        children: [
          Expanded(child: Container(color: Colors.lightGreenAccent)),
          Container(
            color: Colors.grey,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 30, left: 15, right: 15),
              child: Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: messageText,
                      decoration: InputDecoration(
                        hintText: 'Write the message here.......',
                        border: InputBorder.none,
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      sendmessages();
                    },
                    child: Icon(Icons.send),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
